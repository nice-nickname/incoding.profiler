chrome.devtools.panels.create("Incoding profiler","","panel.html",(function(e){}));
//# sourceMappingURL=loader.js.map